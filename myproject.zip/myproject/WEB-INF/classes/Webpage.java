import javax.servlet.*;
import java.io.*;
public class Webpage extends GenericServlet
{
	public void service(ServletRequest req,ServletResponse res)throws ServletException,IOException
	{
		res.setContentType("text/html");
		PrintWriter ou=res.getWriter();
		ou.println("<h1>Hello This is first web servlet </h1>");
	}

}