import javax.servlet.*;
import java.io.*;
public class Login extends GenericServlet
{
	public void service(ServletRequest req,ServletResponse res)throws IOException,ServletException
	{
		String username=req.getParameter("name");
		String pass=req.getParameter("pwd");
		
		String Id="yaswanth";
		String pws="admin";
		PrintWriter out=res.getWriter();
		if(username.equals(Id) && pass.equals(pws))
		{
			out.println("<h1> Welcome to "+username+"</h1>");
			out.println("Login Successfull");
			//out.println(username);
			//out.println(pass);
		}
		else
		{
			out.println("<h1>Invalid User</h1>");
		}
	}
}