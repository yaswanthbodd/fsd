import javax.servlet.*;
import java.io.*;
public class ReadServlet extends GenericServlet
{
	//logic
	public void service(ServletRequest req,ServletResponse res) throws IOException,ServletException
	{
		//Read Input from the form
		// name - Identification of component
		String name=req.getParameter("name");
		String branch=req.getParameter("branch");

		//Print on the browser
		PrintWriter out=res.getWriter();
		out.println(name);
		out.println(branch);
	}

}