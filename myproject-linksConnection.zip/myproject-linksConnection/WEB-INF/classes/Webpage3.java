import javax.servlet.*;
import java.io.*;
public class Webpage3 extends GenericServlet
{
	public void service(ServletRequest req,ServletResponse res) throws IOException,ServletException
	{
		res.setContentType("text/html");
		PrintWriter out=res.getWriter();
		out.println("<h1>Hello This 3rd website</h1><br><a href='/myproject/web1'>yash</a>");
	}
}