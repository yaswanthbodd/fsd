import javax.servlet.*;
import java.io.*;
public class Webpage extends GenericServlet
{
	public void service(ServletRequest req,ServletResponse res)throws ServletException,IOException
	{
		res.setContentType("text/html");
		PrintWriter ou=res.getWriter();
		ou.println("<h1>Hello This is first web servlet </h1><br><h2>click the below.You go to the my 2nd website.<a href='/myproject/web1'>click</a>");
	}

}