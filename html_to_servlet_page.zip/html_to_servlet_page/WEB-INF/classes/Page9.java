import javax.servlet.*;
import java.io.*;
public class Page9 extends GenericServlet
{
	public void service(ServletRequest req,ServletResponse res)throws IOException,ServletException
	{
		res.setContentType("text/html");
		PrintWriter out=res.getWriter();
		out.println("<h1>Thanks for submit</h1>");
	}
}